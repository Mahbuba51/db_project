create table food_order (
	food_id BIGINT NOT NULL,
	order_id BIGINT NOT NULL,
	no_of_servings INT NOT NULL CHECK (no_of_servings > 0),
	promotion_details VARCHAR(50),
	price INT NOT NULL CHECK (price > 0),
	PRIMARY KEY (food_id, order_id),
	FOREIGN KEY (food_id) REFERENCES food(id),
	FOREIGN KEY (order_id) REFERENCES orders(id)
);
insert into food_order (food_id, order_id, no_of_servings, promotion_details, price) values (1, 1, 1, null, 429);
