create table review (
	id BIGSERIAL PRIMARY KEY NOT NULL,
	score INT NOT NULL CHECK (score >= 0 AND score <= 5),
	comment TEXT,
	customer_id BIGINT NOT NULL REFERENCES customer(id),
	restaurant_id BIGINT NOT NULL REFERENCES restaurant(id)
);
insert into review (score, comment, customer_id, restaurant_id) values (1, 'Vestibulum ac est lacinia nisi venenatis tristique. Fusce congue, diam id ornare imperdiet, sapien urna pretium nisl, ut volutpat sapien arcu sed augue. Aliquam erat volutpat.

In congue. Etiam justo. Etiam pretium iaculis justo.', 3, 5);
insert into review (score, comment, customer_id, restaurant_id) values (0, 'Curabitur in libero ut massa volutpat convallis. Morbi odio odio, elementum eu, interdum eu, tincidunt in, leo. Maecenas pulvinar lobortis est.', 10, 2);
insert into review (score, comment, customer_id, restaurant_id) values (4, 'Curabitur in libero ut massa volutpat convallis. Morbi odio odio, elementum eu, interdum eu, tincidunt in, leo. Maecenas pulvinar lobortis est.

Phasellus sit amet erat. Nulla tempus. Vivamus in felis eu sapien cursus vestibulum.

Proin eu mi. Nulla ac enim. In tempor, turpis nec euismod scelerisque, quam turpis adipiscing lorem, vitae mattis nibh ligula nec sem.', 8, 4);
