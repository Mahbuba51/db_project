create table driver (
	id BIGSERIAL PRIMARY KEY NOT NULL,
	user_name VARCHAR(50) NOT NULL,
	password VARCHAR(50) NOT NULL,
	name VARCHAR(50) NOT NULL,
	contact_no VARCHAR(50) NOT NULL,
	driving_license_no VARCHAR(50) NOT NULL,
	monthly_payment INT NOT NULL CHECK (monthly_payment > 0)
);
insert into driver (user_name, password, name, contact_no, driving_license_no, monthly_payment) values ('mroofe0', 'zT8\20~NG', 'Murielle Roofe', '+66 118 739 6744', 'DU-070949-VO', 22852);
insert into driver (user_name, password, name, contact_no, driving_license_no, monthly_payment) values ('hdyke1', 'xZ6=VI@Up57sNM', 'Had Dyke', '+81 709 892 8186', 'MI-321939-ZM', 13534);
insert into driver (user_name, password, name, contact_no, driving_license_no, monthly_payment) values ('kmarritt2', 'tA0|s6Xn', 'Kimmy Marritt', '+256 448 453 2339', 'QK-633949-YN', 24910);
insert into driver (user_name, password, name, contact_no, driving_license_no, monthly_payment) values ('dthorouggood3', 'yW3/c8p0kJneN>A', 'Devondra Thorouggood', '+98 533 396 6258', 'YH-010177-GH', 12989);
insert into driver (user_name, password, name, contact_no, driving_license_no, monthly_payment) values ('cdanielsohn4', 'bV1#{cYsb_SQspc', 'Catlin Danielsohn', '+54 788 918 6081', 'WM-897916-EI', 24300);
insert into driver (user_name, password, name, contact_no, driving_license_no, monthly_payment) values ('cschuricke5', 'lE8+\Bwj(29P', 'Chiarra Schuricke', '+387 190 481 2898', 'FQ-644574-KF', 26170);
insert into driver (user_name, password, name, contact_no, driving_license_no, monthly_payment) values ('msrutton6', 'tS0,pKi0A8@*h3', 'Marni Srutton', '+351 926 831 0077', 'RP-108076-NZ', 13915);
insert into driver (user_name, password, name, contact_no, driving_license_no, monthly_payment) values ('thowis7', 'uU3&NWq@H+@R', 'Tedie Howis', '+502 890 348 4592', 'GZ-714074-FX', 22472);
insert into driver (user_name, password, name, contact_no, driving_license_no, monthly_payment) values ('gsteven8', 'qL3=ynx>', 'Garv Steven', '+62 286 896 5604', 'JB-120732-MO', 24455);
insert into driver (user_name, password, name, contact_no, driving_license_no, monthly_payment) values ('mpoppy9', 'iB9=U$sJ', 'Malvin Poppy', '+63 593 907 7123', 'ZH-103134-TV', 18561);
