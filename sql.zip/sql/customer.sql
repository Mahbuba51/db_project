create table customer (
	id BIGSERIAL PRIMARY KEY NOT NULL,
	name VARCHAR(50) NOT NULL,
	contact_no VARCHAR(50) NOT NULL,
	location VARCHAR(50) NOT NULL,
	email VARCHAR(50) NOT NULL
);
insert into customer (name, contact_no, location, email) values ('Chloe Kewley', '+976 153 635 1606', '37 Cordelia Place', 'ckewley0@ifeng.com');
insert into customer (name, contact_no, location, email) values ('Elianora Ferrick', '+380 826 628 6427', '424 Vahlen Crossing', 'eferrick1@google.ca');
insert into customer (name, contact_no, location, email) values ('Bartlett Nason', '+47 892 144 0556', '85321 Ramsey Way', 'bnason2@tamu.edu');
insert into customer (name, contact_no, location, email) values ('Carole Feld', '+380 726 841 7943', '72242 Comanche Point', 'cfeld3@dmoz.org');
insert into customer (name, contact_no, location, email) values ('Bogart Clarkson', '+52 318 599 3619', '0550 Westend Alley', 'bclarkson4@posterous.com');
insert into customer (name, contact_no, location, email) values ('Neddie Monnery', '+86 390 417 5591', '2 Stang Drive', 'nmonnery5@free.fr');
insert into customer (name, contact_no, location, email) values ('Marcy Cosbey', '+351 612 919 3653', '2432 Schlimgen Center', 'mcosbey6@ucoz.com');
insert into customer (name, contact_no, location, email) values ('Pippy Leggs', '+63 574 173 4699', '8 North Center', 'pleggs7@washingtonpost.com');
insert into customer (name, contact_no, location, email) values ('Roma Brantzen', '+63 110 377 3839', '1882 Longview Terrace', 'rbrantzen8@ihg.com');
insert into customer (name, contact_no, location, email) values ('Teodor Robken', '+66 927 509 5981', '846 Debs Crossing', 'trobken9@google.co.jp');
