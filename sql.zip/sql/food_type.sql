create table food_type (
	id BIGSERIAL PRIMARY KEY NOT NULL,
	type_name VARCHAR(50),
	maintype_id BIGINT,
	CONSTRAINT fk_type FOREIGN KEY (maintype_id) REFERENCES food_type(id) ON DELETE CASCADE
);
insert into food_type (type_name, maintype_id) values ('Baked goods', null);
insert into food_type (type_name, maintype_id) values ('Breakfast', null);
insert into food_type (type_name, maintype_id) values ('Lunch', null);
insert into food_type (type_name, maintype_id) values ('Dinner', null);
insert into food_type (type_name, maintype_id) values ('Pastry', null);
insert into food_type (type_name, maintype_id) values ('Italian', 4);
insert into food_type (type_name, maintype_id) values ('Mexican', 2);
insert into food_type (type_name, maintype_id) values ('Chinese', 4);
insert into food_type (type_name, maintype_id) values ('Indian', 3);
insert into food_type (type_name, maintype_id) values ('Japanese', 4);
insert into food_type (type_name, maintype_id) values ('Greek', 3);
insert into food_type (type_name, maintype_id) values ('Thai', 2);
insert into food_type (type_name, maintype_id) values ('American', 1);
insert into food_type (type_name, maintype_id) values ('French', 5);
insert into food_type (type_name, maintype_id) values ('Mediterranean', 4);