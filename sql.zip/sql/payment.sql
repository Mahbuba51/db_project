create table payment (
	id BIGSERIAL PRIMARY KEY NOT NULL,
	payment_type VARCHAR(20) NOT NULL,
	tips INT,
	order_id BIGINT NOT NULL REFERENCES orders(id)
);
insert into payment (payment_type, tips, order_id) values ('mobile payment', 79, 1);
