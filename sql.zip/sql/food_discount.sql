create table food_discount (
	food_id BIGINT,
	discount_id BIGINT,
	PRIMARY KEY (food_id, discount_id),
	FOREIGN KEY (food_id) REFERENCES food(id),
	FOREIGN KEY (discount_id) REFERENCES discount(id)
);
insert into food_discount (food_id, discount_id) values (171, 70);
insert into food_discount (food_id, discount_id) values (201, 20);
insert into food_discount (food_id, discount_id) values (132, 82);
insert into food_discount (food_id, discount_id) values (439, 60);
insert into food_discount (food_id, discount_id) values (490, 32);
insert into food_discount (food_id, discount_id) values (153, 5);
insert into food_discount (food_id, discount_id) values (405, 62);
insert into food_discount (food_id, discount_id) values (306, 7);
insert into food_discount (food_id, discount_id) values (285, 22);
insert into food_discount (food_id, discount_id) values (332, 28);
