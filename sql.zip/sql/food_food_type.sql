create table food_food_type (
	food_id BIGINT,
	food_type_id BIGINT,
	PRIMARY KEY (food_id, food_type_id),
	FOREIGN KEY (food_id) REFERENCES food(id),
	FOREIGN KEY (food_type_id) REFERENCES food_type(id)

);
insert into food_food_type (food_id, food_type_id) values (138, 10);
insert into food_food_type (food_id, food_type_id) values (278, 14);
insert into food_food_type (food_id, food_type_id) values (128, 5);
insert into food_food_type (food_id, food_type_id) values (218, 5);
insert into food_food_type (food_id, food_type_id) values (42, 11);
insert into food_food_type (food_id, food_type_id) values (382, 6);
insert into food_food_type (food_id, food_type_id) values (244, 6);
insert into food_food_type (food_id, food_type_id) values (139, 9);
insert into food_food_type (food_id, food_type_id) values (490, 12);
insert into food_food_type (food_id, food_type_id) values (4, 9);
