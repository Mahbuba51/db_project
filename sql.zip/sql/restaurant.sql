create table restaurant (
	id BIGSERIAL PRIMARY KEY NOT NULL,
	name VARCHAR(50) NOT NULL,
	contact_no VARCHAR(50) NOT NULL,
	email VARCHAR(50) NOT NULL,
	location VARCHAR(50) NOT NULL,
	opening_time TIME NOT NULL,
	closing_time TIME NOT NULL CHECK (closing_time > opening_time)
);
insert into restaurant (name, contact_no, email, location, opening_time, closing_time) values ('The Hungry Spoon', '+86 351 629 4548', 'mcatherine0@google.com', '1234 Oak Alley', '8:47:00', '23:56:00');
insert into restaurant (name, contact_no, email, location, opening_time, closing_time) values ('Cafe Delight', '+355 687 794 6356', 'lfaich1@newyorker.com', '729 Raven Circle', '9:26:00', '23:36:00');
insert into restaurant (name, contact_no, email, location, opening_time, closing_time) values ('Bistro Bliss', '+86 524 445 6701', 'ssimper2@360.cn', '6094 Meadow Valley Park', '11:16:00', '23:02:00');
insert into restaurant (name, contact_no, email, location, opening_time, closing_time) values ('The Savory Plate', '+7 511 722 7830', 'cstreeting3@ibm.com', '88 Sycamore Crossing', '8:34:00', '23:13:00');
insert into restaurant (name, contact_no, email, location, opening_time, closing_time) values ('Gourmet Junction', '+62 186 290 8800', 'gstanhope4@deliciousdays.com', '76 Hoffman Place', '10:17:00', '23:48:00');
insert into restaurant (name, contact_no, email, location, opening_time, closing_time) values ('The Tasty Bite', '+63 521 122 6131', 'tmosen5@rambler.ru', '4 Clyde Gallagher Circle', '9:12:00', '23:53:00');
insert into restaurant (name, contact_no, email, location, opening_time, closing_time) values ('Foodie Haven', '+86 695 738 5220', 'lniave6@pbs.org', '196 Roxbury Park', '13:32:00', '23:05:00');
insert into restaurant (name, contact_no, email, location, opening_time, closing_time) values ('Flavorsome Grill', '+7 446 660 9636', 'troussell7@washington.edu', '25 Sutteridge Lane', '12:11:00', '23:30:00');
insert into restaurant (name, contact_no, email, location, opening_time, closing_time) values ('The Culinary Corner', '+86 135 215 7730', 'belia8@sciencedirect.com', '9 Maywood Parkway', '9:37:00', '23:57:00');
insert into restaurant (name, contact_no, email, location, opening_time, closing_time) values ('Dine & Dash', '+237 408 212 6680', 'cgarroch9@blogspot.com', '28 Corscot Hill', '12:34:00', '23:46:00');
