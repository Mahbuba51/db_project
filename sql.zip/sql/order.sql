create table orders (
	id BIGSERIAL PRIMARY KEY NOT NULL,
	date DATE  NOT NULL,
	total_amount INT NOT NULL CHECK (total_amount > 0),
	promotion_discount INT,
	special_instructions VARCHAR(150),
	delivery_charge INT NOT NULL CHECK (delivery_charge >= 0),
	order_time TIME NOT NULL,
    delivery_time TIME NOT NULL CHECK (delivery_time > order_time),
	delivery_location VARCHAR(50) NOT NULL,
	status VARCHAR(30) NOT NULL,
	customer_id BIGINT NOT NULL REFERENCES customer(id),
	driver_id BIGINT NOT NULL REFERENCES driver(id),
	promotion_id BIGINT NOT NULL REFERENCES discount(id)
);
insert into orders (date, total_amount, promotion_discount, special_instructions, delivery_charge, order_time, delivery_time, delivery_location, status, customer_id, driver_id, promotion_id) values ('2024-01-01', 417, 230, null, 54, '11:07:50', '12:03:01', '8 Sommers Point', 'Returned to Sender', 8, 4, 46);
